import os
import subprocess
import sys

import time
import shutil

def get_terminal_size():
    return shutil.get_terminal_size()

def center_text(text, width):
    lines = text.splitlines()
    centered_lines = [line.center(width) for line in lines]
    return "\n".join(centered_lines)

def blinking():
    text = """
⠀⠀ ⠀             █████               
           ▒▒███                
 █████ ████ ▒███████    ████████
▒▒███ ▒███  ▒███▒▒███  ███▒▒███ 
 ▒███ ▒███  ▒███ ▒███ ▒███ ▒███ 
 ▒███ ▒███  ▒███ ▒███ ▒███ ▒███ 
 ▒▒████████ ████ █████▒▒███████ 
  ▒▒▒▒▒▒▒▒ ▒▒▒▒ ▒▒▒▒▒  ▒▒▒▒▒███ 
                           ▒███ 
                           █████
 new                         ▒▒▒▒▒ 
 
    """
    terminal_size = get_terminal_size()
    centered_text = center_text(text, terminal_size.columns)
    
    for _ in range(3):
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"\033[31m{centered_text}\033[0m")
        time.sleep(0.5)
        os.system('cls' if os.name == 'nt' else 'clear')
        time.sleep(0.5)

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    
    blinking()
    
    os.system('cls' if os.name == 'nt' else 'clear')
    
    menu = """
                                                                                                                  
    ▄▄▄▄▄▄▄▄▄▄▄▄▄▄ ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄    ▄▄▄▄▄▄▄▄ ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄    ▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄ ▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄    ▄▄▄▄▄▄▄▄▄▄▄▄   
 ▄▀▀             ░ ▄              ▀▄  ▄      ▓ ▄              ▀▄  ▄      ▓  ▄      █ ▄      ▓  ▄      █  ▄▀            ▀▄ 
▐▌     ▄▄▄▄     ▒▒ █               ▐▌ █      ▒ █               ▐▌ █      ▒  ▒      █ █      ▒  ▒     ▒█ ▐▌              ▐▌
█      ░  ░     ░▓ ▓               ░█ ▓      ░ ▓      ▒▀▀░     ░▒ ▓      ▒  ░      █ ▓      ░  ░     ░█ ▓      █▀▀▒     ░█
▒      ▒  ▀▀▀▀▀▀▀▀ ▒      █▀▀█      █ ▒      █ ▒      ░  ▒     ▐▌ ▒      ░  ▀█     █ ▒      █  █      █ ▒      █  ░      █
▐▌      ▀▄▄▄▄▄▄    ░      █  ░     ┼█ ░      █ ░      ▀▀▀▀   ▄▄▀  ░      █   ░     █ ░      █▄▄█    ┼┼█ ░      █  █▄     █
 ▀▄▄         ┼┼▀▄  █┼     █  ▒    ┼┼█ █┼     █ █┼     ▒▀▀▀▀▀▀     █┼  ┼  █   ▒    ┼░ █┼ ┼          ┼┼┼█ █┼     █   ░    ┼░
    ▀▀▀▀▀▄▄┼├├┼├├▌ █┼    ┼█  ▓┼    ┼█ █┼    ┼█ █┼┼   ┼░    ░      █┼┼┼┼┼┼█   ▓┼   ┼▒ █┼┼┼┼ ┼█▀▀█┼   ┼┼█ █┼┼┼┼ ┼█   ▒┼  ┼┼▒
▀▀▀▀▀▀▀░  ▒┼├├┼├├▓ █┼┼  ┼┼░  ▒┼    ┼░ █┼┼  ┼┼░ █┼┼┼┼┼┼░  ·░░░     █┼┼┼┼┼┼█   █┼┼┼┼┼▓ █┼┼┼┼┼┼░  █┼┼┼ ┼┼░ █┼┼┼┼┼┼█ ▀▀▀┼┼ ┼┼▓
▒┼┼├┼┼┼▒▄▄▓┼┼├┼┼▐▌ █┼┼┼┼┼┼▒  ░┼┼┼ ┼┼▒ █┼┼┼┼┼┼▒ █┼┼┼┼┼┼▒  ░▒▒░     ▐▌┼┼┼┼┼█▄▄▄▀┼┼┼┼▐▌ █┼┼┼┼┼┼▒  █┼┼┼┼┼┼▒ ▐▌┼┼┼┼┼█▄█┼┼┼┼┼┼▀▄
░┼├┼┼┼┼┼┼┼┼┼┼┼┼▄▀  █┼┼┼┼┼┼▓  █┼┼┼┼┼┼▓ █┼┼┼┼┼┼▓ █┼┼┼┼┼┼▓  ░░░       ▀▄┼┼┼┼┼┼┼┼┼┼┼┼▄▀  █┼┼┼┼┼┼▓  █┼┼┼┼┼┼▓  ▀▄┼┼┼┼┼┼┼┼┼┼▄┼┼┼▓
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀    ▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀ ▀▀▀▀▀▀▀▀ ▀▀▀▀▀▀▀▀   ░ ·        ▀▀▀▀▀▀▀▀▀▀▀▀    ▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀    ▀▀▀▀▀▀▀▀▀▀ ▀▀▀▀

- github https://github.com/introuvable1133

(1) start
  """
    while True:
        print(f"\033[35m{menu}\033[0m")

        try:
            choice = int(input('uhq>> '))
        except ValueError:
            print('Please enter a number.')
            continue

        if choice == 1:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            sniper_path = os.path.join(script_dir, 'tools', 'sniper.py')
            if not os.path.isfile(sniper_path):
                print(f'Script introuvable : {sniper_path}')
                continue
            subprocess.run([sys.executable, sniper_path], cwd=script_dir)
if __name__ == '__main__':
    main() 
